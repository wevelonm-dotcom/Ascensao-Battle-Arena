import { FormEvent, useState } from 'react'
import { ArrowLeft, Eye, EyeOff, KeyRound, Mail, ShieldCheck, Swords, UserRound } from 'lucide-react'
import { supabase } from './lib/supabase'

type Mode = 'login' | 'signup' | 'recovery'

export default function AuthScreen() {
  const [mode, setMode] = useState<Mode>('login')
  const [name, setName] = useState('')
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [showPassword, setShowPassword] = useState(false)
  const [busy, setBusy] = useState(false)
  const [message, setMessage] = useState('')
  const [error, setError] = useState('')

  async function submit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault()
    if (!supabase) return
    setBusy(true); setMessage(''); setError('')
    try {
      if (mode === 'signup') {
        const { data, error: authError } = await supabase.auth.signUp({
          email: email.trim(), password,
          options: { data: { display_name: name.trim() }, emailRedirectTo: window.location.origin },
        })
        if (authError) throw authError
        setMessage(data.session
          ? 'Conta criada! Sua sessão já está ativa.'
          : 'Cadastro iniciado! Confira seu e-mail para confirmar a conta e depois entre.')
        if (!data.session) setMode('login')
      } else if (mode === 'recovery') {
        const { error: authError } = await supabase.auth.resetPasswordForEmail(email.trim(), { redirectTo: `${window.location.origin}/` })
        if (authError) throw authError
        setMessage('Se esse e-mail estiver cadastrado, você receberá um link para redefinir a senha.')
      } else {
        const { error: authError } = await supabase.auth.signInWithPassword({ email: email.trim(), password })
        if (authError) throw authError
      }
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Não foi possível concluir. Tente novamente.')
    } finally { setBusy(false) }
  }

  const title = mode === 'signup' ? 'Crie sua conta' : mode === 'recovery' ? 'Recuperar acesso' : 'Entre na Arena'
  const description = mode === 'signup' ? 'Sua jornada começa com uma conta.' : mode === 'recovery' ? 'Enviaremos um link para o e-mail informado.' : 'Acesse suas fichas e prepare-se para o combate.'

  return <main className="auth-screen">
    <div className="auth-orbit orbit-one"/><div className="auth-orbit orbit-two"/>
    <section className="auth-card">
      <div className="auth-brand"><div className="auth-brand-mark"><Swords size={25}/></div><div><strong>ASCENSÃO</strong><span>BATTLE ARENA</span></div></div>
      <div className="auth-heading"><span className="section-kicker">ACESSO AO SISTEMA</span><h1>{title}</h1><p>{description}</p></div>
      <form onSubmit={submit} className="auth-form">
        {mode === 'signup' && <label>Nome de jogador<div className="auth-input"><UserRound size={17}/><input value={name} onChange={e => setName(e.target.value)} placeholder="Como quer ser chamado?" required minLength={2} maxLength={40}/></div></label>}
        <label>E-mail<div className="auth-input"><Mail size={17}/><input type="email" value={email} onChange={e => setEmail(e.target.value)} placeholder="seu@email.com" required autoComplete="email"/></div></label>
        {mode !== 'recovery' && <label>Senha<div className="auth-input"><KeyRound size={17}/><input type={showPassword ? 'text' : 'password'} value={password} onChange={e => setPassword(e.target.value)} placeholder="Mínimo de 6 caracteres" required minLength={6} autoComplete={mode === 'signup' ? 'new-password' : 'current-password'}/><button type="button" className="password-toggle" onClick={() => setShowPassword(v => !v)} aria-label={showPassword ? 'Ocultar senha' : 'Mostrar senha'}>{showPassword ? <EyeOff size={17}/> : <Eye size={17}/>}</button></div></label>}
        {mode === 'login' && <button type="button" className="text-action recovery-link" onClick={() => { setMode('recovery'); setMessage(''); setError('') }}>Esqueci minha senha</button>}
        {error && <div className="auth-alert error">{error}</div>}
        {message && <div className="auth-alert success">{message}</div>}
        <button className="primary-button auth-submit" type="submit" disabled={busy}>{busy ? 'Aguarde...' : mode === 'signup' ? 'Criar conta' : mode === 'recovery' ? 'Enviar link de recuperação' : 'Entrar'}</button>
      </form>
      <div className="auth-switch">{mode === 'login' ? <>Ainda não tem conta? <button onClick={() => { setMode('signup'); setMessage(''); setError('') }}>Criar cadastro</button></> : mode === 'signup' ? <>Já possui uma conta? <button onClick={() => { setMode('login'); setMessage(''); setError('') }}>Fazer login</button></> : <button className="back-login" onClick={() => { setMode('login'); setMessage(''); setError('') }}><ArrowLeft size={14}/> Voltar ao login</button>}</div>
      <div className="auth-security"><ShieldCheck size={15}/> Conta protegida pelo Supabase Auth</div>
    </section>
    <p className="auth-footer">FORJE SEU DESTINO · VERSÃO 0.4.0</p>
  </main>
}

export function PasswordUpdateScreen({ onDone }: { onDone: () => void }) {
  const [password, setPassword] = useState('')
  const [confirm, setConfirm] = useState('')
  const [busy, setBusy] = useState(false)
  const [error, setError] = useState('')
  const [success, setSuccess] = useState(false)
  async function submit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault()
    if (!supabase) return
    if (password !== confirm) { setError('As senhas não são iguais.'); return }
    setBusy(true); setError('')
    const { error: updateError } = await supabase.auth.updateUser({ password })
    setBusy(false)
    if (updateError) { setError(updateError.message); return }
    setSuccess(true)
  }
  return <main className="auth-screen"><section className="auth-card"><div className="auth-brand"><div className="auth-brand-mark"><Swords size={25}/></div><div><strong>ASCENSÃO</strong><span>BATTLE ARENA</span></div></div><div className="auth-heading"><span className="section-kicker">RECUPERAÇÃO DE ACESSO</span><h1>Nova senha</h1><p>Escolha uma nova senha para sua conta.</p></div>{success ? <><div className="auth-alert success">Senha atualizada com sucesso. Você já pode continuar.</div><button className="primary-button auth-submit" onClick={onDone}>Continuar</button></> : <form className="auth-form" onSubmit={submit}><label>Nova senha<div className="auth-input"><KeyRound size={17}/><input type="password" value={password} onChange={e => setPassword(e.target.value)} minLength={6} required placeholder="Mínimo de 6 caracteres"/></div></label><label>Confirmar nova senha<div className="auth-input"><KeyRound size={17}/><input type="password" value={confirm} onChange={e => setConfirm(e.target.value)} minLength={6} required placeholder="Digite novamente"/></div></label>{error && <div className="auth-alert error">{error}</div>}<button className="primary-button auth-submit" disabled={busy}>{busy ? 'Salvando...' : 'Salvar nova senha'}</button></form>}<div className="auth-security"><ShieldCheck size={15}/> Recuperação segura pelo Supabase Auth</div></section></main>
}
