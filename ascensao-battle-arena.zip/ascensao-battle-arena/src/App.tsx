import { useEffect, useState } from 'react'
import type { Session } from '@supabase/supabase-js'
import {
  Swords, Shield, Users, Trophy, Settings, Plus, ChevronRight,
  Sparkles, BookOpen, CircleUserRound, Menu, X, Activity, LogOut
} from 'lucide-react'
import AuthScreen, { PasswordUpdateScreen } from './AuthScreen'
import { supabase, supabaseConfigured } from './lib/supabase'

type Page = 'inicio' | 'personagens' | 'arsenal' | 'arena' | 'salas' | 'ranking' | 'configuracoes'
const navigation: { id: Page; label: string; icon: typeof Swords }[] = [
  { id: 'inicio', label: 'Visão geral', icon: Activity },
  { id: 'personagens', label: 'Personagens', icon: CircleUserRound },
  { id: 'arsenal', label: 'Arsenal', icon: Sparkles },
  { id: 'arena', label: 'Arena', icon: Swords },
  { id: 'salas', label: 'Salas', icon: Users },
  { id: 'ranking', label: 'Ranking', icon: Trophy },
]
const pageCopy: Record<Page, { eyebrow: string; title: string; description: string }> = {
  inicio: { eyebrow: 'CENTRO DE COMANDO', title: 'Sua próxima batalha começa aqui.', description: 'Prepare seus personagens, organize suas estratégias e entre na Arena.' },
  personagens: { eyebrow: 'FORJA DE PERSONAGENS', title: 'Personagens', description: 'Crie fichas completas e monte combatentes com as regras adaptadas do Ascensão.' },
  arsenal: { eyebrow: 'BIBLIOTECA DE COMBATE', title: 'Arsenal', description: 'Habilidades, técnicas, passivas, equipamentos e efeitos.' },
  arena: { eyebrow: 'COMBATE', title: 'Arena', description: 'O campo onde estratégias, atributos e decisões se encontram.' },
  salas: { eyebrow: 'MULTIPLAYER', title: 'Salas de batalha', description: 'Crie uma sala privada e reúna seus adversários.' },
  ranking: { eyebrow: 'COMPETITIVO', title: 'Ranking', description: 'Acompanhe resultados e desempenho dos combatentes.' },
  configuracoes: { eyebrow: 'PREFERÊNCIAS', title: 'Configurações', description: 'Ajustes gerais do Battle Arena.' },
}

function App() {
  const [session, setSession] = useState<Session | null>(null)
  const [authLoading, setAuthLoading] = useState(true)
  const [passwordRecovery, setPasswordRecovery] = useState(false)
  const [page, setPage] = useState<Page>('inicio')
  const [mobileOpen, setMobileOpen] = useState(false)
  const [playerName, setPlayerName] = useState('Viajante')
  const [rolls, setRolls] = useState<number | null>(null)
  const [characterCount, setCharacterCount] = useState<number | null>(null)
  const [signingOut, setSigningOut] = useState(false)
  const current = pageCopy[page]

  useEffect(() => {
    if (!supabase) { setAuthLoading(false); return }
    supabase.auth.getSession().then(({ data }) => { setSession(data.session); setAuthLoading(false) })
    const { data: listener } = supabase.auth.onAuthStateChange((event, nextSession) => {
      if (event === 'PASSWORD_RECOVERY') setPasswordRecovery(true)
      setSession(nextSession)
      setAuthLoading(false)
    })
    return () => listener.subscription.unsubscribe()
  }, [])

  useEffect(() => {
    if (!session || !supabase) return
    let active = true
    async function loadAccount() {
      const user = session!.user
      const metadataName = user.user_metadata?.display_name
      if (active) setPlayerName(typeof metadataName === 'string' && metadataName.trim() ? metadataName : (user.email?.split('@')[0] || 'Viajante'))
      const [{ data: wallet }, { count }] = await Promise.all([
        supabase!.from('wallets').select('rolls').eq('user_id', user.id).maybeSingle(),
        supabase!.from('characters').select('*', { count: 'exact', head: true }).eq('user_id', user.id),
      ])
      if (active) { setRolls(typeof wallet?.rolls === 'number' ? wallet.rolls : 0); setCharacterCount(count ?? 0) }
    }
    loadAccount()
    return () => { active = false }
  }, [session])

  async function signOut() {
    if (!supabase) return
    setSigningOut(true)
    await supabase.auth.signOut()
    setSigningOut(false)
    setPage('inicio')
  }
  function navigate(next: Page) { setPage(next); setMobileOpen(false) }

  if (!supabaseConfigured) return <div className="setup-screen"><div className="setup-card"><div className="auth-brand"><div className="auth-brand-mark"><Swords size={25}/></div><div><strong>ASCENSÃO</strong><span>BATTLE ARENA</span></div></div><span className="section-kicker">CONFIGURAÇÃO NECESSÁRIA</span><h1>Conecte seu projeto Supabase.</h1><p>O projeto está pronto para receber as credenciais públicas. No Replit, abra Secrets e adicione:</p><code>VITE_SUPABASE_URL</code><code>VITE_SUPABASE_PUBLISHABLE_KEY</code><p className="setup-note">Use a Project URL e a Publishable Key. Nunca coloque a senha do banco ou a Secret Key no frontend.</p></div></div>
  if (authLoading) return <div className="loading-screen"><div className="auth-brand-mark"><Swords size={25}/></div><p>Preparando a Arena...</p></div>
  if (passwordRecovery) return <PasswordUpdateScreen onDone={() => setPasswordRecovery(false)} />
  if (!session) return <AuthScreen />

  return <div className="app-shell">
    <aside className={`sidebar ${mobileOpen ? 'sidebar-open' : ''}`}>
      <div className="brand"><div className="brand-mark"><Swords size={22} /></div><div><strong>ASCENSÃO</strong><span>BATTLE ARENA</span></div><button className="icon-button close-menu" onClick={() => setMobileOpen(false)} aria-label="Fechar menu"><X /></button></div>
      <div className="sidebar-label">NAVEGAÇÃO</div>
      <nav>{navigation.map(item => { const Icon = item.icon; return <button key={item.id} className={`nav-item ${page === item.id ? 'active' : ''}`} onClick={() => navigate(item.id)}><Icon size={18} /><span>{item.label}</span>{page === item.id && <span className="nav-indicator" />}</button> })}</nav>
      <div className="sidebar-bottom"><button className={`nav-item ${page === 'configuracoes' ? 'active' : ''}`} onClick={() => navigate('configuracoes')}><Settings size={18}/><span>Configurações</span></button><div className="profile-mini"><div className="avatar">{playerName.slice(0,1).toUpperCase()}</div><div className="profile-name"><strong>{playerName}</strong><span>{session.user.email}</span></div><button className="logout-icon" onClick={signOut} aria-label="Sair da conta" title="Sair"><LogOut size={16}/></button></div></div>
    </aside>
    {mobileOpen && <button className="scrim" onClick={() => setMobileOpen(false)} aria-label="Fechar navegação" />}
    <main className="main-content">
      <header className="topbar"><button className="icon-button mobile-menu" onClick={() => setMobileOpen(true)} aria-label="Abrir menu"><Menu /></button><div className="breadcrumb">BATTLE ARENA <ChevronRight size={14}/> <span>{current.title}</span></div><div className="topbar-right"><span className="status-dot" /> CONTA CONECTADA <div className="top-avatar">{playerName.slice(0,1).toUpperCase()}</div><button className="top-logout" onClick={signOut} disabled={signingOut}>{signingOut ? 'Saindo...' : 'Sair'}</button></div></header>
      <div className="page-wrap"><section className="hero"><div className="hero-content"><div className="eyebrow"><span /> {current.eyebrow}</div><h1>{current.title}</h1><p>{current.description}</p>{page === 'inicio' && <div className="hero-actions"><button className="primary-button" onClick={() => navigate('personagens')}><Plus size={17}/> Criar personagem</button><button className="secondary-button" onClick={() => navigate('arena')}><Swords size={17}/> Abrir arena</button></div>}</div><div className="hero-emblem"><div className="emblem-ring"><Swords size={54}/></div><span>ASCENSÃO</span><small>FORJE SEU DESTINO</small></div></section>
        {page === 'inicio' ? <Dashboard navigate={navigate} rolls={rolls} characterCount={characterCount} playerName={playerName}/> : <ModulePlaceholder page={page} navigate={navigate}/>}
        <footer><span>ASCENSÃO: BATTLE ARENA</span><span>VERSÃO 0.4.0 · AUTENTICAÇÃO</span></footer>
      </div>
    </main>
  </div>
}

function Dashboard({ navigate, rolls, characterCount, playerName }: { navigate: (page: Page) => void; rolls: number | null; characterCount: number | null; playerName: string }) {
  const cards = [
    { title: 'Personagens', desc: 'Forje seu combatente', icon: CircleUserRound, page: 'personagens' as Page, number: '01' },
    { title: 'Arsenal', desc: 'Organize suas habilidades', icon: Sparkles, page: 'arsenal' as Page, number: '02' },
    { title: 'Arena', desc: 'Teste suas estratégias', icon: Swords, page: 'arena' as Page, number: '03' },
    { title: 'Salas', desc: 'Prepare uma partida online', icon: Users, page: 'salas' as Page, number: '04' },
  ]
  return <>
    <section className="account-welcome"><div><span className="section-kicker">BEM-VINDO À ARENA</span><h2>{playerName}</h2><p>Sua conta está conectada e pronta para avançar.</p></div><div className="account-stats"><div><span>ROLLS</span><strong>{rolls === null ? '—' : rolls}</strong></div><div><span>PERSONAGENS</span><strong>{characterCount === null ? '—' : `${characterCount}/2`}</strong></div></div></section>
    <section className="section-heading"><div><span className="section-kicker">ACESSO RÁPIDO</span><h2>Escolha seu próximo passo</h2></div><span className="muted">01 / 04</span></section>
    <div className="module-grid">{cards.map(card => { const Icon = card.icon; return <button className="module-card" key={card.page} onClick={() => navigate(card.page)}><div className="module-card-top"><div className="module-icon"><Icon size={21}/></div><span>{card.number}</span></div><div><h3>{card.title}</h3><p>{card.desc}</p></div><div className="card-arrow"><ChevronRight size={18}/></div></button> })}</div>
    <section className="lower-grid"><div className="panel roadmap-panel"><div className="panel-heading"><div><span className="section-kicker">DESENVOLVIMENTO</span><h2>Construindo a fundação</h2></div><BookOpen size={20}/></div><div className="progress-track"><span /></div><div className="progress-meta"><strong>Etapa 02 — Contas e persistência</strong><span>Em andamento</span></div><ul className="check-list"><li className="done">Interface responsiva e navegação</li><li className="done">Cadastro, login e recuperação de senha</li><li className="done">Banco de dados e proteção por usuário</li><li>Criação e evolução de personagens</li></ul></div><div className="panel rules-panel"><span className="section-kicker">REGRAS DO PROJETO</span><h2>Ascensão, adaptado para PvP.</h2><p>Cada conta terá até dois espaços de ficha. Rolls serão compartilhados pela conta; XP, nível e P.A. pertencem a cada personagem.</p><div className="rule-tags"><span>2 FICHAS</span><span>ROLLS COMPARTILHADOS</span><span>COMBATE HÍBRIDO</span></div></div></section>
  </>
}

function ModulePlaceholder({ page, navigate }: { page: Page; navigate: (page: Page) => void }) {
  const Icon = page === 'arena' ? Swords : page === 'salas' ? Users : page === 'ranking' ? Trophy : page === 'arsenal' ? Sparkles : page === 'configuracoes' ? Settings : Shield
  return <section className="module-placeholder panel"><div className="placeholder-icon"><Icon size={30}/></div><span className="section-kicker">PRÓXIMA IMPLEMENTAÇÃO</span><h2>Este módulo será construído na próxima etapa.</h2><p>Sua conta já está conectada. Agora vamos implementar as fichas, a progressão e os sistemas de jogo com salvamento real.</p><button className="secondary-button" onClick={() => navigate('inicio')}>Voltar à visão geral</button></section>
}
export default App
