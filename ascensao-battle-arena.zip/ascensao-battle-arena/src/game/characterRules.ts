/** Regras de montagem de ficha do Battle Arena.
 * Os limites competitivos ficam centralizados para facilitar ajustes.
 */
export const CHARACTER_LIMITS = {
  talentSlots: 2,
  passiveSlots: 3,
  abilitySlots: 4,
} as const

export const ROULETTE_CATEGORIES = [
  "talentos",
  "magias",
  "habilidades",
  "passivas",
  "pa",
] as const

export type RouletteCategory = typeof ROULETTE_CATEGORIES[number]
