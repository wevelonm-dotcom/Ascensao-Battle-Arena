# Banco de dados — Supabase

A Etapa 2 conecta a autenticação do Supabase e prepara persistência segura para contas e fichas.

## Estrutura
- `profiles`: perfil associado à conta autenticada.
- `wallets`: carteira de Rolls compartilhada pela conta.
- `characters`: até dois espaços de personagem por conta (`slot` 1 ou 2); XP, nível e P.A. são individuais.
- `roll_transactions`: histórico de concessões e gastos de Rolls, com referência única para ajudar a impedir duplicidade.

## Migração
O arquivo `migrations_001_initial_schema.sql` pode ser executado no Supabase > SQL Editor. Ele usa `IF NOT EXISTS` e recria as políticas com segurança para facilitar a repetição.

Se você já executou a migração da Etapa 2 anterior e as quatro tabelas aparecem no Table Editor, não precisa executar outra vez. A estrutura foi mantida compatível com esses nomes e campos.

## Segurança
- RLS habilitado em todas as tabelas.
- Usuários só consultam e alteram os próprios personagens.
- Carteira e histórico de Rolls são somente leitura pelo navegador. A concessão/retirada de Rolls deverá ser feita por lógica confiável no servidor, nunca por uma chave secreta no cliente.
- O limite de dois personagens também é protegido pela restrição única `(user_id, slot)` e pelo intervalo de slots 1–2.

Nunca exponha `service_role`, Secret Key ou a senha do banco no frontend.
