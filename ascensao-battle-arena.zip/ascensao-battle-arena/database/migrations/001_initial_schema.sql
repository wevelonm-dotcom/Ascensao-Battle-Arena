-- ASCENSAO: BATTLE ARENA | schema inicial (seguro para executar mais de uma vez)
-- Execute no Supabase > SQL Editor. Não coloque chaves secretas no frontend.

create extension if not exists pgcrypto;

create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  display_name text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.wallets (
  user_id uuid primary key references auth.users(id) on delete cascade,
  rolls integer not null default 0 check (rolls >= 0),
  updated_at timestamptz not null default now()
);

create table if not exists public.characters (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  slot smallint not null check (slot between 1 and 2),
  name text not null default 'Novo personagem',
  level integer not null default 1 check (level >= 1),
  xp bigint not null default 0 check (xp >= 0),
  pa integer not null default 0 check (pa >= 0),
  sheet jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  constraint characters_user_slot_unique unique (user_id, slot)
);

create table if not exists public.roll_transactions (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  amount integer not null check (amount <> 0),
  source text not null,
  reference_id text not null,
  description text,
  created_at timestamptz not null default now(),
  constraint roll_transactions_source_reference_unique unique (user_id, source, reference_id)
);

create index if not exists characters_user_id_idx on public.characters(user_id);
create index if not exists roll_transactions_user_id_created_idx on public.roll_transactions(user_id, created_at desc);

-- Cria perfil e carteira automaticamente quando o Supabase Auth cria uma conta.
create or replace function public.handle_new_battle_arena_user()
returns trigger
language plpgsql
security definer
set search_path = public
as $$
begin
  insert into public.profiles (id, display_name)
  values (new.id, coalesce(new.raw_user_meta_data ->> 'display_name', split_part(new.email, '@', 1)))
  on conflict (id) do nothing;

  insert into public.wallets (user_id, rolls)
  values (new.id, 0)
  on conflict (user_id) do nothing;

  return new;
end;
$$;

drop trigger if exists on_auth_user_created_battle_arena on auth.users;
create trigger on_auth_user_created_battle_arena
after insert on auth.users
for each row execute procedure public.handle_new_battle_arena_user();

alter table public.profiles enable row level security;
alter table public.wallets enable row level security;
alter table public.characters enable row level security;
alter table public.roll_transactions enable row level security;

drop policy if exists "profiles_select_own" on public.profiles;
create policy "profiles_select_own" on public.profiles for select to authenticated using (auth.uid() = id);
drop policy if exists "profiles_update_own" on public.profiles;
create policy "profiles_update_own" on public.profiles for update to authenticated using (auth.uid() = id) with check (auth.uid() = id);

drop policy if exists "wallets_select_own" on public.wallets;
create policy "wallets_select_own" on public.wallets for select to authenticated using (auth.uid() = user_id);
-- Não há política de UPDATE/INSERT/DELETE para a carteira: Rolls só serão concedidos
-- por operações confiáveis no servidor, evitando que o navegador altere o saldo.

drop policy if exists "characters_select_own" on public.characters;
create policy "characters_select_own" on public.characters for select to authenticated using (auth.uid() = user_id);
drop policy if exists "characters_insert_own" on public.characters;
create policy "characters_insert_own" on public.characters for insert to authenticated with check (auth.uid() = user_id);
drop policy if exists "characters_update_own" on public.characters;
create policy "characters_update_own" on public.characters for update to authenticated using (auth.uid() = user_id) with check (auth.uid() = user_id);
drop policy if exists "characters_delete_own" on public.characters;
create policy "characters_delete_own" on public.characters for delete to authenticated using (auth.uid() = user_id);

drop policy if exists "roll_transactions_select_own" on public.roll_transactions;
create policy "roll_transactions_select_own" on public.roll_transactions for select to authenticated using (auth.uid() = user_id);
-- Histórico de Rolls é somente leitura para o cliente.

grant usage on schema public to authenticated;
grant select, update on public.profiles to authenticated;
grant select on public.wallets to authenticated;
grant select, insert, update, delete on public.characters to authenticated;
grant select on public.roll_transactions to authenticated;
