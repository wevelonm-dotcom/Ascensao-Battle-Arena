# Ascensão: Battle Arena — Etapa 2 (0.4.0)

Base web responsiva do simulador PvP de Ascensão, agora com autenticação Supabase.

## O que esta etapa entrega

- Cadastro com nome de jogador, e-mail e senha.
- Login e sessão persistente.
- Recuperação de senha por e-mail.
- Integração com Supabase Auth usando Project URL + Publishable Key.
- Perfil e carteira de Rolls criados automaticamente após o cadastro.
- Estrutura PostgreSQL para até dois personagens por conta.
- Rolls compartilhados por conta; XP, nível e P.A. individuais por personagem.
- Row Level Security (RLS) nas tabelas e políticas para separar os dados de cada usuário.
- Saldo de Rolls e quantidade de personagens exibidos no painel.
- Os 395 resultados das cinco roletas originais e suas probabilidades foram preservados.

## Configuração no Replit (pelo Android)

1. Crie um projeto React/Vite no Replit ou importe este ZIP.
2. Abra **Tools / Secrets** (o nome pode variar conforme a interface).
3. Adicione `VITE_SUPABASE_URL` com a Project URL do Supabase.
4. Adicione `VITE_SUPABASE_PUBLISHABLE_KEY` com a Publishable Key (`sb_publishable_...`).
5. Execute `npm install` e depois `npm run dev`.
6. Abra a prévia do site e teste o cadastro.

Se a ferramenta de importação solicitar um arquivo, envie este ZIP completo. Não envie credenciais em mensagens ou em arquivos públicos.

## Banco de dados

A migração está em `database/migrations/001_initial_schema.sql`. Como o banco do projeto já foi criado e as tabelas aparecem no Table Editor, não execute a migração novamente agora. Ela está incluída para referência e para uma instalação nova.

Tabelas: `profiles`, `wallets`, `characters`, `roll_transactions`.

## Segurança importante

- Use somente Project URL e Publishable Key no frontend.
- Nunca use `service_role`, Secret Key ou senha do banco no navegador.
- RLS impede que uma conta leia ou altere fichas de outra conta.
- O navegador não pode editar o saldo nem o histórico de Rolls. As recompensas de missões, conquistas, níveis e batalhas precisarão ser validadas por lógica confiável no servidor.
- O limite de dois personagens está modelado por dois slots (`1` e `2`) no banco. A interface de criação e edição de fichas será a próxima etapa.

## Comandos

- `npm run dev`: desenvolvimento.
- `npm run typecheck`: verificação TypeScript.
- `npm run validate:data`: valida os dados das roletas.
- `npm run build`: valida e gera a versão de produção.

Requisitos: Node.js 20+ e npm.
