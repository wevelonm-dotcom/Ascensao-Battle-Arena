import fs from 'node:fs'
import path from 'node:path'
import { fileURLToPath } from 'node:url'

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..')
const file = path.join(root, 'src/data/rouletteData.json')
const data = JSON.parse(fs.readFileSync(file, 'utf8'))
const expected = ['talentos', 'magias', 'habilidades', 'passivas', 'pa']
const expectedCounts = { talentos: 86, magias: 79, habilidades: 89, passivas: 86, pa: 55 }
const problems = []
let grandTotal = 0

for (const category of expected) {
  const roulette = data[category]
  if (!roulette?.tiers || typeof roulette.tiers !== 'object') {
    problems.push(`Categoria ausente ou inválida: ${category}`)
    continue
  }

  let total = 0
  let chance = 0
  for (const [tierKey, tier] of Object.entries(roulette.tiers)) {
    if (!Array.isArray(tier.items)) problems.push(`${category}/${tierKey}: lista de itens inválida`)
    else total += tier.items.length
    if (typeof tier.chance !== 'number') problems.push(`${category}/${tierKey}: chance inválida`)
    else chance += tier.chance
  }

  grandTotal += total
  if (total !== expectedCounts[category]) problems.push(`${category}: esperado ${expectedCounts[category]} itens, encontrado ${total}`)
  if (Math.abs(chance - 100) > 0.000001) problems.push(`${category}: chances somam ${chance}% em vez de 100%`)
  console.log(`✓ ${category}: ${total} itens; probabilidades somam ${chance}%`)
}

for (const extra of Object.keys(data)) {
  if (!expected.includes(extra)) problems.push(`Categoria não permitida no pacote: ${extra}`)
}

if (grandTotal !== 395) problems.push(`Total geral esperado: 395; encontrado: ${grandTotal}`)
if (problems.length) {
  console.error('\nFalha na validação:\n- ' + problems.join('\n- '))
  process.exit(1)
}
console.log(`\nDados validados: ${grandTotal} resultados em ${expected.length} roletas.`)
